

 +++ {Paper Daisy} DEMO +++

Version 1.1 - June 2018


Free for PERSONAL USE only!


+ + + + + + + + + + + +


To add the floral symbols to your text, set the font to Paper Daisy and copy & paste the following symbols: []


+ + + + + + + + + + + +


The commercial version contains international characters, punctuation marks and cute symbols.

It can be purchased here: https://creativemarket.com/maja.mint?u=maja.mint


+ + + + + + + + + + + +


++ Contact: Jana Matthaeus - info@majamint.com

++ Paper Daisy DEMO - a handwritten condensed font � maja.mint (Jana Matthaeus) 2016. All Rights Reserved